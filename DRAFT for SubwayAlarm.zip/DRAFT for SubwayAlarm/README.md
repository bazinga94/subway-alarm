# Alarm-ios-swift     

Full functional clone of the apple's official clock alarm application for study purpose.     
Now supports Swift 3.


## Branch     

`master`     
newest stable version branch.

`swift-3.0.1`      
current develop branch.

`others`         
some old feature branches that not maintained.

## Demo     
<img src="https://github.com/natsu1211/Alarm-ios-swift/blob/swift-3.0.1/gif/alarm-ios-swift.gif" width="45%" height="45%"> 

## License      
MIT
