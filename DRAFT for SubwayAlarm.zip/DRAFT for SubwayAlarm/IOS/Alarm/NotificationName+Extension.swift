//
//  NotificationName+Extension.swift
//  Alarm-ios-swift
//
//  Created by natsu1211 on 2017/04/18.
//  Copyright © 2017年 LongGames. All rights reserved.
//

import Foundation

extension NSNotification.Name {
    static let AlarmDisableNotification = NSNotification.Name("AlarmDisableNotification")
}
