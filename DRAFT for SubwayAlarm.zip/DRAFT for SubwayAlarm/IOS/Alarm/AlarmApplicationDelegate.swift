//
//  AlarmApplicationDelegate.swift
//  Alarm-ios-swift
//
//  Created by natsu1211 on 2017/01/31.
//  Copyright © 2017年 LongGames. All rights reserved.
//

import Foundation

protocol AlarmApplicationDelegate {
    func playSound(_ soundName: String)
}
